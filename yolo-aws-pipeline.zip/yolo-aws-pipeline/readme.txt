========================================================================
AWS IMAGE OBJECT IDENTIFICATION SYSTEM USING YOLOV5 & SERVERLESS PIPELINE
========================================================================

STUDENT IDENTIFICATION
----------------------------------
Student Name: Muhammad Zihadul Islam
Student ID: 240198

PROJECT DESCRIPTION
------------------------------
This project builds an automated object detection pipeline on AWS.  It uses the YOLOv5 machine learning model to find objects inside images.

DIRECTORY STRUCTURE OVERVIEW
-----------------------------------------------
/code - Contains runtime microservice files: lambda_function.py and backend app.py
/deploy - Contains automated environment baseline and dependency setup script deploy.sh
/images - Contains laboratory verification snapshots illustrating functional success states